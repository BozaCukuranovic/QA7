package tests;

import methods.LogInMethods;
import org.junit.Assert;
import org.junit.Test;
import pages.VerifyPage;
import utilities.PropertyManager;

public class BlankPasswordFailedLoginTest extends BaseTest{

    public LogInMethods logInMethods;
    public VerifyPage verifyPage;


    @Test
    public void blankPasswordFailedLoginTest (){
        logInMethods = new LogInMethods(driver);
        verifyPage = new VerifyPage(driver);


        logInMethods.loginBlankPassword (PropertyManager.getInstance().getUserName());


        try {

            verifyPage.verifyFailedLogin("Epic sadface: Password is required");
            System.out.print("User is Not logged in");

        } catch (Exception e) {
            Assert.fail("User IS logged in!");


        }
    }
}