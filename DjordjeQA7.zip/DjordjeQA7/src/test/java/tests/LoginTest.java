package tests;

import methods.LogInMethods;
import org.junit.Assert;
import org.junit.Test;
import pages.VerifyPage;
import utilities.PropertyManager;

public class LoginTest extends BaseTest{

    public LogInMethods logInMethods;
    public VerifyPage verifyPage;

    @Test
    public void loginTest (){
        logInMethods = new LogInMethods(driver);
        verifyPage = new VerifyPage(driver);

        logInMethods.login(PropertyManager.getInstance().getUserName(),
                PropertyManager.getInstance().getPassword());


        try {

            verifyPage.verifyLogin("PRODUCTS");
            System.out.print("User IS logged in");

        } catch (Exception e) {
            Assert.fail("User IS NOT logged in!");


        }
    }

}
