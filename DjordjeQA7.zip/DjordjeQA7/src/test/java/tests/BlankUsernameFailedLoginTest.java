package tests;

import methods.LogInMethods;
import org.junit.Assert;
import org.junit.Test;
import pages.VerifyPage;
import utilities.PropertyManager;

public class BlankUsernameFailedLoginTest extends BaseTest{


    public LogInMethods logInMethods;
    public VerifyPage verifyPage;

    @Test
    public void blankUsernameLogin () {
        logInMethods = new LogInMethods(driver);
        verifyPage = new VerifyPage(driver);


        logInMethods.loginBlankUsername(PropertyManager.getInstance().getPassword());


        try {

            verifyPage.verifyFailedLogin("Epic sadface: Username is required");
            System.out.print("User is Not logged in");

        } catch (Exception e) {
            Assert.fail("User IS logged in!");


        }
    }
}


