package tests;

import methods.LogInMethods;
import org.junit.Assert;
import org.junit.Test;
import pages.VerifyPage;
import utilities.PropertyManager;

public class FailedLoginTest extends BaseTest{


    public LogInMethods logInMethods;
    public VerifyPage verifyPage;

    @Test
    public void failedLoginTest (){
        logInMethods = new LogInMethods(driver);
        verifyPage = new VerifyPage(driver);

        logInMethods.login(PropertyManager.getInstance().getBadUserName(),
                PropertyManager.getInstance().getBadPassword());

        try {

            verifyPage.verifyFailedLogin("Epic sadface: Username and password do not match any user in this service");
            System.out.print("User is Not logged in");

        } catch (Exception e) {
            Assert.fail("User IS logged in!");


        }
    }


}
