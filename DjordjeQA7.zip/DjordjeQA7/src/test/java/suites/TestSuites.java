package suites;

import base_test_with_login.CompleteCheckoutTest;
import base_test_with_login.LogoutTest;
import base_test_with_login.RemoveBackpackItemFromShoppingCartTest;
import base_test_with_login.VerifyCorrectItemInCartList;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import tests.BlankPasswordFailedLoginTest;
import tests.BlankUsernameFailedLoginTest;
import tests.FailedLoginTest;
import tests.LoginTest;

@RunWith(Suite.class)

@Suite.SuiteClasses({

        BlankPasswordFailedLoginTest.class,
        BlankUsernameFailedLoginTest.class,
        FailedLoginTest.class,
        LoginTest.class,
        LogoutTest.class,
        RemoveBackpackItemFromShoppingCartTest.class,
        CompleteCheckoutTest.class,
        VerifyCorrectItemInCartList.class,

})

public class TestSuites {
}
