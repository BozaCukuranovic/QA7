package base_test_with_login;

import methods.LogInMethods;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import pages.VerifyPage;
import tests.BaseTest;
import utilities.PropertyManager;

import java.util.concurrent.TimeUnit;

public class BaseTestWithLogin extends BaseTest {

    public WebDriver driver;
    public ChromeOptions options;
    public LogInMethods logInMethods;
    public VerifyPage verifyPage;

    @Before
    public void setup (){

        options = new ChromeOptions();
        // disable browser pop ups. They can make test run improperly.
        options.addArguments("--disable-notifications");

        System.setProperty("webdriver.chrome.driver", PropertyManager.getInstance().getDriverPath());
        String baseURL = PropertyManager.getInstance().getURL();

        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();

        logInMethods = new LogInMethods(driver);
        verifyPage = new VerifyPage(driver);

        driver.get(baseURL);
        logInMethods.login(PropertyManager.getInstance().getUserName(),
                PropertyManager.getInstance().getPassword());

    }

    public void teardown (){
        driver.quit();
    }
}
