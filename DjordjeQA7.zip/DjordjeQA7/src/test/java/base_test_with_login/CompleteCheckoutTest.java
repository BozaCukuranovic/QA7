package base_test_with_login;

import methods.CartListMethods;
import methods.CheckoutInfoMethods;
import methods.InventoryMethods;
import org.junit.Assert;
import org.junit.Test;
import pages.CheckoutOverviewPage;
import utilities.PropertyManager;

public class CompleteCheckoutTest extends BaseTestWithLogin{

    public InventoryMethods inventoryMethods;
    public CartListMethods cartListMethods;
    public CheckoutInfoMethods checkoutInfoMethods;
    public CheckoutOverviewPage checkoutOverviewPage;


    @Test
    public void completeCheckoutTest (){

        inventoryMethods = new InventoryMethods(driver);
        cartListMethods = new CartListMethods(driver);
        checkoutInfoMethods = new CheckoutInfoMethods(driver);
        checkoutOverviewPage = new CheckoutOverviewPage(driver);


        inventoryMethods.addToCartBackPack();
        cartListMethods.clickCheckout();
        checkoutInfoMethods.writeInfoForm(PropertyManager.getInstance().getFirstName(),
                PropertyManager.getInstance().getLastName(),
                PropertyManager.getInstance().getPostalCode());
        checkoutOverviewPage.clickFinish();


        try {

            verifyPage.verifyFinishCheckout("CHECKOUT: COMPLETE!");
            System.out.print("Checkout IS complete!");

        } catch (Exception e) {
            Assert.fail("Checkout IS NOT complete");
    }
}

}
