package base_test_with_login;

import methods.InventoryMethods;
import org.junit.Assert;
import org.junit.Test;
import pages.VerifyPage;

public class LogoutTest extends BaseTestWithLogin{

    public VerifyPage verifyPage;
    public InventoryMethods inventoryMethods;


    @Test
    public void logOutTest (){

        inventoryMethods = new InventoryMethods(driver);
        verifyPage = new VerifyPage(driver);

        inventoryMethods.logOut();


        try {

            verifyPage.verifyLogout("Login");
            System.out.print("User is logout");

        } catch (Exception e) {
            Assert.fail("User is not logout!");
    }
}

}
