package base_test_with_login;

import methods.CartListMethods;
import methods.InventoryMethods;
import org.junit.Assert;
import org.junit.Test;

public class RemoveBackpackItemFromShoppingCartTest extends BaseTestWithLogin{

    public InventoryMethods inventoryMethods;
    public CartListMethods cartListMethods;


    @Test
    public void removeBackPackFromShoppingCartTest (){

        inventoryMethods = new InventoryMethods(driver);
        cartListMethods = new CartListMethods(driver);

        inventoryMethods.addToCartBackPack();
        cartListMethods.removeBackPackItem();



        try {
            verifyPage.verifyRemoveBackPack("ADD TO CART");
            System.out.print("Item removed");
        } catch (Exception e) {
            Assert.fail("Item is in shopping cart");
    }
}
}
