package base_test_with_login;

import methods.InventoryMethods;
import org.junit.Assert;
import org.junit.Test;

public class VerifyCorrectItemInCartList extends BaseTestWithLogin{

    public InventoryMethods inventoryMethods;



    @Test
    public void verifyCorrectItemInCartList (){

        inventoryMethods = new InventoryMethods(driver);


        inventoryMethods.addToCartBackPack();


        try {
            verifyPage.verifyCorrectItemBackPack("Sauce Labs Backpack");
            System.out.print("Correct Item");
        } catch (Exception e) {
            Assert.fail("Back Pack is not in cart list");
    }
}
}
