package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutInfoPage extends BasePage{

    public CheckoutInfoPage (WebDriver driver){
        super(driver);
    }
    By continueButtonBy=By.id("continue");
    By firstNameFieldBy = By.id("first-name");
    By lastNameFieldBy=By.id("last-name");
    By postalCodeFieldBy=By.id("postal-code");


    public CheckoutInfoPage writeFirstName (String first_name){
        writeText(firstNameFieldBy, first_name);
        return this;
    }
    public CheckoutInfoPage writeLastName (String last_name){
        writeText(lastNameFieldBy, last_name);
        return this;
    }
    public CheckoutInfoPage writePostalCode (String postal_code){
        writeText(postalCodeFieldBy, postal_code);
        return this;
    }
    public CheckoutInfoPage clickContinue (){
        click(continueButtonBy);
        return this;
    }
}
