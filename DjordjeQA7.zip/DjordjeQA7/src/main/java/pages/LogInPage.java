package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LogInPage extends BasePage{
    public LogInPage (WebDriver driver){
        super(driver);
    }

    By logInButtonBy = By.id("login-button");
    By userNameBy = By.id("user-name");
    By passwordBy = By.id("password");


    public LogInPage clickLogIn (){
        click(logInButtonBy);
        return this;
    }
    public LogInPage writeUserName (String text){
        writeText(userNameBy, text);
        return this;
    }
    public LogInPage writePassword (String text){
        writeText (passwordBy, text);
        return this;
    }
}
