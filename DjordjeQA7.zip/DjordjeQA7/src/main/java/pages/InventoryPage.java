package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class InventoryPage extends BasePage{

    public InventoryPage (WebDriver driver){
        super(driver);
    }
    By logoutButtonBy=By.id("logout_sidebar_link");
    By popUpMenuButtonBy = By.id("react-burger-menu-btn");
    By addToCartBackPackButtonBy=By.id("add-to-cart-sauce-labs-backpack");
    By shoppingCartButtonBy=By.className("shopping_cart_link");

    public InventoryPage clickPopUpMenu (){
        click(popUpMenuButtonBy);
        return this;
    }
    public InventoryPage clickLogOut (){
        click (logoutButtonBy);
       return this;
    }
    public InventoryPage clickAddToCartBackPack (){
        click(addToCartBackPackButtonBy);
        return this;
    }
    public InventoryPage clickShoppingCartButton (){
        click(shoppingCartButtonBy);
        return this;
    }
}
