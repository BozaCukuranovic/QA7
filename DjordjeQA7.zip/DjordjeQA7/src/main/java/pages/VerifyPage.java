package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class VerifyPage extends BasePage{
    public VerifyPage (WebDriver driver){
        super(driver);
    }

    By completeCheckoutMessage = By.className ("title");
    By addToCartBackPackButtonBy = By.id ("add-to-cart-sauce-labs-backpack");
    By loginNotificationBy = By.className ("title");
    //use ctrl+f then $x to find good x path
    By errorNotificationBy = By.xpath ("//h3[@data-test=\"error\"]");
    By logInButtonBy = By.id ("login-button");
    By itemCartListBackPack=By.xpath ("//div[@class=\"inventory_item_name\"]");



    public VerifyPage verifyFailedLogin (String expectedText){
        String alert = readText(errorNotificationBy);
        assertStringEquals(alert, expectedText);
        return this;
    }
    public VerifyPage verifyLogin (String expectedText){
        String products = readText(loginNotificationBy);
        return this;
    }
    public VerifyPage verifyLogout (String value){
        String attributeText = readTextByAttribute(logInButtonBy,"value");
        assertStringEquals(attributeText, value);
        return this;
    }
    public VerifyPage verifyRemoveBackPack (String expectedText){
        String empty = readText(addToCartBackPackButtonBy);
        return this;
    }
    public VerifyPage verifyFinishCheckout (String expectedText){
        String finish = readText(completeCheckoutMessage);
        return this;
    }
    public VerifyPage verifyCorrectItemBackPack (String expectedText){
        String item = readText(itemCartListBackPack);
        return this;
    }
}
