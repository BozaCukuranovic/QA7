package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartListPage extends BasePage{

    public CartListPage (WebDriver driver){
        super(driver);
    }

    By removeBackPackButtonBy = By.id("remove-sauce-labs-backpack");
    By continueShoppingButtonBy= By.id("continue-shopping");
    By checkoutButtonBy=By.id("checkout");
    By itemCartListBackPackBy=By.xpath("//div[@class=\"inventory_item_name\"]");

    public CartListPage clickRemoveBackPackButton (){
        click(removeBackPackButtonBy);
        return this;
    }
    public CartListPage clickContinueShopping (){
        click(continueShoppingButtonBy);
        return this;
    }
    public CartListPage clickCheckout (){
        click(checkoutButtonBy);
        return this;
    }
    public CartListPage clickItemCartListBackPack (){
        click(itemCartListBackPackBy);
        return this;
    }
}

