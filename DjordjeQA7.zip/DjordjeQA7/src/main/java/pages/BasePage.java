package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {

    WebDriver driver;
    WebDriverWait wait;

    public BasePage (WebDriver driver){
        this.driver = driver;
        wait = new WebDriverWait(driver,15);

    }

    public void waitVisibility (By elementBy){
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));
    }

    public BasePage click (By elementBy){
        waitVisibility(elementBy);
        driver.findElement(elementBy).click();
        return null;
    }

    public void writeText (By elementBy, String text){
        waitVisibility(elementBy);
        driver.findElement(elementBy).clear();
        driver.findElement(elementBy).sendKeys(text);
    }

    public String readText (By elementBy) {
        waitVisibility(elementBy);
        return driver.findElement(elementBy).getText();
    }

    public String readTextByAttribute (By elementBy, String value){
        waitVisibility(elementBy);
        String attributeText = driver.findElement(elementBy).getAttribute(value);
        return attributeText;
    }

    public void assertStringEquals (String string, String expectedText){
        Assert.assertEquals(string, expectedText);
    }



}
