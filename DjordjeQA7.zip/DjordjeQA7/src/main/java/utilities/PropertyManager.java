package utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyManager {


    private static String postal_code;
    private static String last_name;
    private static String bad_log_in_password;
    private static String driverPath;
    private static String first_name;
    private static String password;
    private static String url;
    private static String user_name;
    private static String bad_user_name;


    public static PropertyManager getInstance(){

        Properties prop = new Properties();
        PropertyManager instance = new PropertyManager();
        try {
            FileInputStream configuration = new FileInputStream("src/main/resources/configuration.properties");
            prop.load(configuration);

        } catch (Exception e){
            e.printStackTrace();
        }


        bad_log_in_password = prop.getProperty ("bad_login_password");
        url = prop.getProperty ("url");
        password = prop.getProperty ("password");
        first_name = prop.getProperty ("first_name");
        driverPath = prop.getProperty ("driverPath");
        last_name = prop.getProperty ("last_name");
        user_name = prop.getProperty ("user_name");
        bad_user_name = prop.getProperty ("bad_user_name");
        postal_code = prop.getProperty ("postal_code");
        return instance;
    }

    public String getBadPassword (){
        return bad_log_in_password;
    }
    public String getURL (){
        return url;
    }
    public String getFirstName (){
        return first_name;
    }
    public String getPassword (){
        return password;
    }
    public String getLastName (){
        return last_name;
    }
    public String getPostalCode (){
        return postal_code;
    }
    public String getDriverPath (){
        return driverPath;
    }
    public String getUserName (){
        return user_name;
    }
    public String getBadUserName (){
        return bad_user_name;
    }
}
