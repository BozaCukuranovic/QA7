package methods;

import org.openqa.selenium.WebDriver;
import pages.CheckoutInfoPage;

public class CheckoutInfoMethods extends CheckoutInfoPage {

    public CheckoutInfoMethods (WebDriver driver){
        super(driver);
    }

    public CheckoutInfoMethods writeInfoForm (String first_name, String last_name, String postal_code){

        writeFirstName(first_name);
        writeLastName(last_name);
        writePostalCode(postal_code);
        clickContinue();
        return this;
    }
}
