package methods;

import org.openqa.selenium.WebDriver;
import pages.CartListPage;

public class CartListMethods extends CartListPage {

    public CartListMethods (WebDriver driver){
        super(driver);
    }


        public CartListMethods removeBackPackItem (){
        clickRemoveBackPackButton();
        clickContinueShopping();
        return this;

    }
}
