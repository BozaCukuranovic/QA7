package methods;

import org.openqa.selenium.WebDriver;
import pages.InventoryPage;

public class InventoryMethods extends InventoryPage {

    public InventoryMethods (WebDriver driver){
        super(driver);
    }


    public InventoryMethods logOut (){

        clickPopUpMenu();
        clickLogOut();
        return this;
    }

    public InventoryMethods addToCartBackPack (){

        clickAddToCartBackPack();
        clickShoppingCartButton();
        return this;
    }
}
