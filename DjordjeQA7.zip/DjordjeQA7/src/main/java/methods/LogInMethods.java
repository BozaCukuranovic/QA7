package methods;

import org.openqa.selenium.WebDriver;
import pages.LogInPage;

public class LogInMethods extends LogInPage {

    public LogInMethods (WebDriver driver){
        super(driver);
    }

    public LogInMethods login (String user_name, String password){

        writeUserName(user_name);
        writePassword(password);
        clickLogIn();
        return this;
    }

    public LogInMethods loginBlankUsername (String password){
        writePassword(password);
        clickLogIn();
        return this;
    }

    public LogInMethods loginBlankPassword (String user_name){
        writeUserName(user_name);
        clickLogIn();
        return this;
    }
}
